/** Automatically generated file. DO NOT MODIFY */
package com.android2ee.formation.gui.global.activitywithlistmenudialog;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}